Version History:
 - 'Amy_Rig_v1.0'
 - 'Amy_Rig_v1.1' - Fixed eyelid and blink issue. 
 - 'Amy_Rig_v1.11' - Fixed left eyelid control.
 - 'Amy_Rig_v1.2' - Relaxed eye pose. Eyelid crease controllers, you can turn the visibility on and off on ctrlBox controller. Breathing deformer, you can control it with RootX_M control. Inside of the mouth follows FKFaceLower_M. Neck rotates from neck base now. Overall adjustments to the position of some controllers. Blink issue solved. Teeth controllers now pivot from the front. Changed position of the nose control and included a nose tip control. Fixed the issue where the inside of her mouth popped with certain rotations.

------------------
Remember to tag your posts on instagram with #AmyRig, #SamRig, #DanaRig or #DavidRig!

Thanks to everyone who has rated this rig on Gumroad, it really helps to spread the word!

I made a twitter account to post updates for this project: https://twitter.com/gabrielsalas_
You can also find me on Artstation: 
https://www.artstation.com/gabrielsalas
And on Instagram:
https://www.instagram.com/gabrielsalasb/


------------------
Terms of use:

No racist, pornographic or otherwise offensive content.

Educational, non commercial use only. You are allowed to use these rigs on your animation reel or portfolio. To discuss commercial use please get in touch with me using the contact form on my website.

Licenses are for a single user. Only the buyer can use the downloaded files, please refrain from sharing or distributing them in any way.